Examples
--------

The following examples demonstrate some common use-cases of MNE-BIDS.
Each example has a badge called "Binder" at the end. By clicking on that badge,
you can interactively run the examples in your browser.

The examples are loosely ordered from basic to more advanced use cases.
