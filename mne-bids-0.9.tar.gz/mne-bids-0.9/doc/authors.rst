.. _Mainak Jas: https://jasmainak.github.io/
.. _Teon Brooks: https://teonbrooks.github.io/
.. _Chris Holdgraf: https://bids.berkeley.edu/people/chris-holdgraf
.. _Matt Sanderson: https://github.com/monkeyman192
.. _Stefan Appelhoff: https://stefanappelhoff.com/
.. _Romain Quentin: https://github.com/romquentin
.. _Dominik Welke: https://github.com/dominikwelke
.. _Maximilien Chaumon: https://github.com/dnacombo
.. _Ezequiel Mikulan: https://github.com/ezemikulan
.. _Marijn van Vliet: https://github.com/wmvanvliet
.. _Alex Rockhill: https://github.com/alexrockhill
.. _Sophie Herbst: https://github.com/SophieHerbst
.. _Adam Li: https://github.com/adam2392
.. _Fu-Te Wong: https://github.com/zuxfoucault
.. _Richard Höchenberger: https://github.com/hoechenberger
.. _Alexandre Gramfort: http://alexandre.gramfort.net
.. _Ariel Rokem: https://github.com/arokem
.. _Evgenii Kalenkovich: https://github.com/kalenkovich
.. _Austin Hurst: https://github.com/a-hurst
.. _Robert Luke: https://github.com/rob-luke
.. _Ethan Knights: https://github.com/ethanknights
.. _Diego Lozano-Soldevilla: https://github.com/dieloz
.. _Eduard Ort: https://github.com/eort
.. _Tom Donoghue: https://github.com/TomDonoghue
.. _Richard Köhler: https://github.com/richardkoehler
.. _Sin Kim: https://github.com/AKSoo
.. _Jean-Rémi King: https://kingjr.github.io
.. _Julia Guiomar Niso Galán: https://github.com/guiomar
.. _Eric Larson: https://github.com/larsoner
.. _Clemens Brunner: https://github.com/cbrnr
.. _Kambiz Tavabi: https://github.com/ktavabi
.. _Franziska von Albedyll: https://www.researchgate.net/profile/Franziska-Von-Albedyll
