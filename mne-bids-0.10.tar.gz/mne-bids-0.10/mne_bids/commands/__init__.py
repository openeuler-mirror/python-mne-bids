"""Initialize cli."""
