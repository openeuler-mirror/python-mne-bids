"""Create a summary report of the BIDS dataset."""

from ._report import make_report
